<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 21th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

?>

@extends('layouts.app')
<style>
            html, body {
                background-image: linear-gradient(lightskyblue, powderblue);
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }</style>
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">E-Portfolio</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif								

                    <form action="{{ route('users.upload-portfolio') }}" method="POST" enctype="multipart/form-data">
                    
                    @csrf
					
					@method('PUT')
					
<!--                     <div class="form-group"> -->
                    
<!--                     	@include('layouts.image') -->
                    	
<!--                     </div> -->
                    
<!--                     <div class="form-group"> -->

<!--                     	<img name="image" id="image" src="{{ $user->image }}" height="200" width="200"> -->
                    
<!--                     </div> -->
                    
                    <div class="form-group">
                    
                    	<label for="jobHistory">List Any Previous Jobs</label>
                    
                    	<textarea name="jobHistory" id="jobHistory" cols="5" rows="5" class="form-control">{{ $user->jobHistory }}</textarea>
                    
                    </div>
                    
                    <div class="form-group">
                    
                    	<label for="skill">Skills</label>
                    	
                    	<input type="text" class="form-control" name="skill" id="skill" value="{{ $user->skill }}">
                    
                    </div>
                    
                    <div class="form-group">
                    
                    	<label for="education">Education</label>
                    
                    	<input type="text" class="form-control" name="education" id="education" value="{{ $user->education }}">
                    
                    </div>
                    
                    <button type="submit" class="btn btn-success">Submit E-Portfolio</button>
                    
                    </form>                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
